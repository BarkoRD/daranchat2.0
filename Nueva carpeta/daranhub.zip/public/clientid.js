const clientId = () => {
    const generateUniqueId = () => {
      const toid = Math.random() * 123432;
      const id = Math.round(toid);
      return id;
    };

    document.addEventListener('DOMContentLoaded', () => {
      let clientId = localStorage.getItem('clientId');
      if (!clientId) {
        clientId = generateUniqueId();
        localStorage.setItem('clientId', clientId);
      }
      console.log('id:',clientId,'obtenido correctamente');
    });
  }

  clientId();