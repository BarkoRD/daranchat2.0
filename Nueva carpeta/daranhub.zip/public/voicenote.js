const startButton = document.querySelector('.grabarnota');
const stopButton = document.querySelector('.cortarnota');
const recordingsList = document.querySelector('.chatmessages');

let mediaRecorder;
let chunks = [];




// Evento clic del botón "Detener grabación"

stopButton.addEventListener('click', (e) => {
    e.preventDefault()
    startButton.classList.remove('desactivado')
    stopButton.classList.add('desactivado')
    mediaRecorder.stop();
  });

//Evento clic del botón "Iniciar grabación"

startButton.addEventListener('click', async (e) => {
    e.preventDefault()
  startButton.classList.add('desactivado')
  stopButton.classList.remove('desactivado')
  startButton.disabled = true;
  stopButton.disabled = false;
  chunks = [];

    // pedir permiso de microfono
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    // se establece que se recibira audio microfono o video o etc
    mediaRecorder = new MediaRecorder(stream);

    // escucha el evento de "grabando" de media recorder y comienza
    // a guardar el audio en chunks(el array)

    mediaRecorder.addEventListener('dataavailable', e => {
      chunks.push(e.data);
    });

    // escucha el evento de detener la grabacion aqui dentro se convierte el
    // contenido de chunks a un "blob" un blob es un conjunto de datos binarios
    // que se puede transformar en algo en este caso este blob se transformara en audio
    // el blob transformado se metera dentro de un link
    mediaRecorder.addEventListener('stop', () => {
      const blob = new Blob(chunks, { type: 'audio/webm' });
      const audioURL = URL.createObjectURL(blob);

      // Crea un elemento "audio vacio con los controles activados"
      const audio = document.createElement('audio');
      audio.classList.add('voicenote', 'plyr');
      audio.controls = true;
      audio.id = 'player';
      // Crea un "source" que dentro tendra el link del blob ya transformado a audio
      const source = document.createElement('source');
      source.src = audioURL;
      source.type = 'audio/webm';

      // une el source del audio con el elemento audio
      audio.appendChild(source);
      
      // Agrega el elemento de audio al DOM

      const voicenote = document.createElement('div');
      voicenote.classList.add('voicenote')
      voicenote.appendChild(audio)
      recordingsList.appendChild(voicenote);

      //activa el reproductor
   
      const player = new Plyr(audio, {
        speed: {
          selected: 1,
          options: [1.5, 2]
        }
      });
      // Limpia los datos y restablece los botones
      chunks = [];
      startButton.disabled = false;
      stopButton.disabled = true;
    });

    // Comienza la grabación
    mediaRecorder.start();

});

