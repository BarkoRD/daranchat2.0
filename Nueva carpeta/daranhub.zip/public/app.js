
const input = document.querySelector('.input')
const form = document.querySelector('.form')
const chatbox = document.querySelector('.chatmessages')
const formsubmit = document.querySelector('.formsubmit')
const socket = io()
const textarea = document.querySelector('.forminput')



const tourl = (text) => {
    const link = /(https?:\/\/[^\s]+)|(www\.[^\s]+)|(?!www\.\S+\.\S{2,})((\b\w+\b\.\S{2,})\b)/g;
    return text.replace(link, (url) => {
      if (!url.startsWith('http')) {
        url = 'http://' + url;
      }
      return `<a href="${url}" target="_blank">${url}</a>`;
    });
  };



document.addEventListener('DOMContentLoaded', () => {
 
 const input = document.querySelector('.input')
    input.focus()
    socket.emit('client:requestusername')
})

textarea.addEventListener('keydown', (e) => {

    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault()
        chatbox.scrollTop = chatbox.scrollHeight;
        if (input.value.length <= 0) {

            chatbox.scrollTop = chatbox.scrollHeight;
        } else {
 
            sendMessage(input.value, 'pepe')
            input.value = ''

            input.focus();
            chatbox.scrollTop = chatbox.scrollHeight;

        }
    }
});

form.addEventListener('submit', (e) => {

    e.preventDefault()
    chatbox.scrollTop = chatbox.scrollHeight;
    if (input.value.length <= 0) {
        e.preventDefault()
        chatbox.scrollTop = chatbox.scrollHeight;
    } else {
        let clientId = localStorage.getItem('clientId');
        sendMessage(input.value, 'el pepe',clientId)
        input.value = ''

        input.focus();
        chatbox.scrollTop = chatbox.scrollHeight;

    }



})



const sendMessage = (message, owner, id) => {
    socket.emit('client:newmessage', {
        message,
        owner,
        id,
    })
}





const appendMessage = message => {

    let clientId = localStorage.getItem('clientId');
    mensaje = tourl(message.message)

    const div = document.createElement('div');

    div.classList.add('message')
    if (message.id !== clientId) {
        div.innerHTML = `
        <p class="messageowner" >${message.owner}</p>
        <p class="messagemessage" >${mensaje}</p>
    `;
        
    } else {
        div.innerHTML = `
        <p class="yourname" >${message.owner}</p>
        <p class="yourmessage" >${mensaje}</p>
    `;
    }
    chatbox.appendChild(div);



};


socket.on('server:newmessage', message => {

    appendMessage(message);
    textarea.value = ''
});

socket.on('loadMessages', messages => {
    loadMessages(messages)
})


const loadMessages = messages => {
    messages.forEach(e => {
        appendMessage(e)
    });
}

//

const ipRegAccescode = document.querySelector('.ip-reg-accescode')
const ipRegName = document.querySelector('.ip-reg-name')
const ipRegSubmit = document.querySelector('.ip-reg-submit')
const errorbox = document.querySelector('.error-message')


ipRegSubmit.addEventListener('click', (e) => {

    if (ipRegAccescode.value.length <= 0 || ipRegName.value.length <= 0) {
        e.preventDefault()
        console.log('asd')
        errorbox.innerHTML = 'Verifique no haya dejado ningun campo vacio por favor'
    }
})


